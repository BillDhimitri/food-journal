//= require angular
//= require AngularDevise
//= require angular-rails-templates
//= require angular-ui-router
//= require_tree .
