angular.module('foodJournal')

.controller('MainCtrl', [
'$scope',
function($scope){

}])
